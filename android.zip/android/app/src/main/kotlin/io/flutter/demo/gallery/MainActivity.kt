package io.flutter.demo.gallery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
